package Travelling_Ticket;

import java.awt.*;

import javax.swing.*;

import java.util.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;

import User_type.Sign;
import User_type.Login;
import User_type.User;

import Travelling_Ticket.Ticket;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.util.Calendar;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;

import java.text.SimpleDateFormat;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

import javax.swing.JSlider;
import javax.swing.JProgressBar;

import java.awt.Component;

import javax.swing.Box;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;

//import com.toedter.calendar.JCalendar;
//import com.toedter.calendar.JDateChooser;

public class Travelling {

	private JFrame frame;
	private JTextField txtTax;
	private JTextField txtSubTotal;
	private JTextField txtTotal;
	protected JLabel txtPrice;
//	private JCalendar calendar;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField txtDate;
	private JTextField txtTime;
	private JTextField txtTicketNo;
	private JTextField txtFrom;
	private JTextField txtTo;
	private JTextField txtRoute;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Travelling window = new Travelling();
					window.frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	public Travelling() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.getContentPane().setBackground(new Color(248, 248, 255));
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		frame.setBounds(0, 0, 651, 527);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTicketType = new JLabel("Ticket Type");
		lblTicketType.setForeground(new Color(255, 255, 255));
		lblTicketType.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTicketType.setBounds(100, 15, 121, 45);
		frame.getContentPane().add(lblTicketType);
		
		
		final JRadioButton cmbClass = new JRadioButton("Business");
		cmbClass.setFont(new Font("Tahoma", Font.BOLD, 12));
		cmbClass.setBounds(10, 90, 89, 23);
		frame.getContentPane().add(cmbClass);
		
		final JRadioButton rdbtneco = new JRadioButton("Economy");
		rdbtneco.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtneco.setEnabled(true);
		rdbtneco.setSelected(false);
		rdbtneco.setBounds(10, 60, 89, 23);
		frame.getContentPane().add(rdbtneco);
		
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setBounds(10, 310, 615, 2);
		frame.getContentPane().add(separator_7);
		

		JSeparator separator_8 = new JSeparator();
		separator_8.setBounds(10, 15, 320, 2);
		frame.getContentPane().add(separator_8);
		
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 12));
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setText("Confirm Booking?");
		textField.setColumns(10);
		textField.setBounds(10, 320, 131, 30);
		frame.getContentPane().add(textField);
		
		
		 JButton btnyes = new JButton("Yes");
		btnyes.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
				
						JOptionPane.showMessageDialog(null, "Booking confirmed!");
						Ticket info  = new Ticket();
						Ticket.main(null);
					}
				}
			);
		btnyes.setBounds(261, 323, 66, 23);
		frame.getContentPane().add(btnyes);
		btnyes.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnyes.setEnabled(true);
		btnyes.setSelected(false);
		btnyes.setBounds(260, 323, 89, 23);
		frame.getContentPane().add(btnyes);
		
		final JButton btnno = new JButton("No");
		btnno.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
										
					System.exit(0);

				
				btnno.setBounds(471, 460, 66, 23);
				frame.getContentPane().add(btnno);
			}
		});
		btnno.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnno.setEnabled(true);
		btnno.setSelected(false);
		btnno.setBounds(399, 323, 89, 23);
		frame.getContentPane().add(btnno);
		
		
		
		final JRadioButton rdbtnfclass = new JRadioButton("First Class");
		rdbtnfclass.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnfclass.setSelected(false);
		rdbtnfclass.setEnabled(true);
		rdbtnfclass.setBounds(10, 120, 89, 23);
		frame.getContentPane().add(rdbtnfclass);
		
		final JRadioButton rdbtnReturnTicket = new JRadioButton("Return Ticket");
		rdbtnReturnTicket.setFont(new Font("Tahoma", Font.BOLD, 11));
		rdbtnReturnTicket.setBounds(110, 90, 111, 23);
		frame.getContentPane().add(rdbtnReturnTicket);
		
		final JRadioButton rdbtnSingleTicket = new JRadioButton("Single Ticket");
		rdbtnSingleTicket.setFont(new Font("Tahoma", Font.BOLD, 11));
		rdbtnSingleTicket.setBounds(110, 60, 111, 23);
		frame.getContentPane().add(rdbtnSingleTicket);
		
		final JRadioButton rdbtnAdult = new JRadioButton("Adult");
		rdbtnAdult.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnAdult.setBounds(230, 60, 100, 23);
		frame.getContentPane().add(rdbtnAdult);
		
		final JRadioButton rdbtnChild = new JRadioButton("Child");
		rdbtnChild.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnChild.setBounds(230, 90, 100, 23);
		frame.getContentPane().add(rdbtnChild);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 55, 320, 2);
		frame.getContentPane().add(separator);
		
		final JComboBox cmbDestination = new JComboBox();
		cmbDestination.setForeground(Color.BLACK);
		cmbDestination.setFont(new Font("Tahoma", Font.BOLD, 12));
		cmbDestination.setModel(new DefaultComboBoxModel(new String[] {"Destination", "DEHRADUN", "DELHI", "LUCKNOW", "MUMBAI", "CHANDIGARH", "GANDHINAGAR", "LADAKH", "SHIMLA"}));
		cmbDestination.setBounds(132, 121, 176, 20);
		frame.getContentPane().add(cmbDestination);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 150, 320, 10);
		frame.getContentPane().add(separator_1);
		
		JLabel lblTax = new JLabel("Tax");
		lblTax.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTax.setBounds(10, 215, 46, 14);
		frame.getContentPane().add(lblTax);
		
		JLabel lblSubTotal = new JLabel("Sub Total");
		lblSubTotal.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblSubTotal.setBounds(10, 245, 66, 14);
		frame.getContentPane().add(lblSubTotal);
		
/*		JCalendar calendar_1 = new JCalendar();
		calendar_1.setBounds(388, 48, 198, 153);
		frame.getContentPane().add(calendar_1);
		calendar_1.setMinSelectableDate(new Date());
		
		*/
		
		txtTax = new JTextField();
		txtTax.setBounds(135, 215, 86, 17);
		frame.getContentPane().add(txtTax);
		txtTax.setColumns(10);
		
		txtSubTotal = new JTextField();
		txtSubTotal.setBounds(135, 245, 86, 17);
		frame.getContentPane().add(txtSubTotal);
		txtSubTotal.setColumns(10);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTotal.setBounds(10, 275, 46, 14);
		frame.getContentPane().add(lblTotal);
		
		txtTotal = new JTextField();
		txtTotal.setBounds(135, 275, 86, 17);
		frame.getContentPane().add(txtTotal);
		txtTotal.setColumns(10);
		
		
		txtDate = new JTextField();
		txtDate.setBounds(535, 29, 86, 20);
		frame.getContentPane().add(txtDate);
		txtDate.setColumns(10);
		
		txtTime = new JTextField();
		txtTime.setColumns(10);
		txtTime.setBounds(535, 77, 86, 20);
		frame.getContentPane().add(txtTime);

		JLabel lblTicketNo = new JLabel("Ticket No.");
		lblTicketNo.setForeground(Color.WHITE);
		lblTicketNo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTicketNo.setBounds(359, 122, 89, 23);
		frame.getContentPane().add(lblTicketNo);
		
		
		JLabel lblFrom = new JLabel("From");
		lblFrom.setForeground(Color.WHITE);
		lblFrom.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblFrom.setBounds(359, 170, 89, 23);
		frame.getContentPane().add(lblFrom);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setForeground(Color.WHITE);
		lblTo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTo.setBounds(359, 218, 89, 23);
		frame.getContentPane().add(lblTo);
		
		
		JLabel lblRoute = new JLabel("Route");
		lblRoute.setForeground(Color.WHITE);
		lblRoute.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblRoute.setBounds(359, 266, 89, 23);
		frame.getContentPane().add(lblRoute);
		
		
		
		txtFrom = new JTextField();
		txtFrom.setColumns(10);
		txtFrom.setBounds(535, 173, 86, 20);
		frame.getContentPane().add(txtFrom);
		
		txtTo = new JTextField();
		txtTo.setColumns(10);
		txtTo.setBounds(535, 221, 86, 20);
		frame.getContentPane().add(txtTo);
		
		
		txtRoute = new JTextField();
		txtRoute.setColumns(10);
		txtRoute.setBounds(535, 269, 86, 20);
		frame.getContentPane().add(txtRoute);
		
		txtTicketNo = new JTextField();
		txtTicketNo.setColumns(10);
		txtTicketNo.setBounds(535, 125, 86, 20);
		frame.getContentPane().add(txtTicketNo);

		JLabel lblTime = new JLabel("Time");
		lblTime.setForeground(Color.WHITE);
		lblTime.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTime.setBounds(360, 74, 57, 23);
		frame.getContentPane().add(lblTime);
		
		
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(10, 195, 320, 2);
		frame.getContentPane().add(separator_2);
		
		JButton btnTotal = new JButton("Total");
		btnTotal.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				double tax = 19.50;
				double MilesK8 = 125.78;
				double MilesK12 = 125.70;
				double MilesK20 = 145.23;
				double MilesK30 = 155.98;
				double MilesK1 = 45.78;
				double MilesK2 = 35.20;
				double MilesK3 = 95.23;
				double MilesK4 = 85.98;
				double totalCost, eco = 3.58, fclass = 5.60;
				
				
				// =====================================================single ticket ddn=================================================
				
				
				
				if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
					
				{
					
					totalCost = (tax * (MilesK8 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK8 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
					
				{
					
					totalCost = ( tax * (MilesK8 + fclass))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK8 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				{
					
					totalCost = (tax * (MilesK8 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK8 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				
				{
					
					totalCost = (tax * (MilesK8 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK8 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				
				
				//==============================================================LUCKNOW FC============================================================================
				
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
					
				{
					
					totalCost = (tax * (MilesK12 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK12 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
					
				{
					
					totalCost = ( tax * (MilesK12 + fclass)) / 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK12 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				{
					
					totalCost = (tax * (MilesK12 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK12 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				
				{
					
					totalCost = (tax * (MilesK12 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK12 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//============================================================DELHI FC=================================================================================
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
					
				{
					
					totalCost = (tax * (MilesK20 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK20 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
					
				{
					
					totalCost = ( tax * (MilesK20 + fclass))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK20 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				{
					
					totalCost = (tax * (MilesK20 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK20 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				
				{
					
					totalCost = (tax * (MilesK20 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK20 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//====================================================================MUMBAI FC========================================================================
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
					
				{
					
					totalCost = (tax * (MilesK30 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK30 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
					
				{
					
					totalCost = ( tax * (MilesK30 + fclass))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK30 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				{
					
					totalCost = (tax * (MilesK30 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK30 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				
				{
					
					totalCost = (tax * (MilesK30 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK30 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//=============================================================CHANDIGARH FC============================================================================
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
					
				{
					
					totalCost = (tax * (MilesK1 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK1 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
					
				{
					
					totalCost = ( tax * (MilesK1 + fclass))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK1 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				{
					
					totalCost = (tax * (MilesK1 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK1 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				
				{
					
					totalCost = (tax * (MilesK1 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK1 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//==============================================================GANDINAGAR FC============================================================================
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("GANDHINAGAR"))
					
				{
					
					totalCost = (tax * (MilesK2 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK2 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("GANDINAGAR"))
					
				{
					
					totalCost = ( tax * (MilesK2 + fclass)) / 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK2 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("GANDINAGAR"))
				{
					
					totalCost = (tax * (MilesK2 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK2 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("GANDINAGAR"))
				
				{
					
					totalCost = (tax * (MilesK2 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK2 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//============================================================LADAKH FC=================================================================================
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
					
				{
					
					totalCost = (tax * (MilesK3 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK3 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
					
				{
					
					totalCost = ( tax * (MilesK3 + fclass))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK3 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				{
					
					totalCost = (tax * (MilesK3 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK3 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				
				{
					
					totalCost = (tax * (MilesK3 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK3 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//================================================SHIMLA FC===========================================================================================
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
					
				{
					
					totalCost = (tax * (MilesK4 + fclass))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 + fclass);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK4 + fclass + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
					
				{
					
					totalCost = ( tax * (MilesK4 + fclass))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + fclass) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 + fclass);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK4 + fclass + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				{
					
					totalCost = (tax * (MilesK4 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK4 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtnfclass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				
				{
					
					totalCost = (tax * (MilesK4 + fclass * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK4 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("FIRST");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				
				//=========================================================================================================================================================//
				//==============================================================DDN ECO================================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
					
				{
					
					totalCost = (tax * (MilesK8 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK8 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
					
				{
					
					totalCost = ( tax * (MilesK8 + eco))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK8 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				{
					
					totalCost = (tax * (MilesK8 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK8 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				
				{
					
					totalCost = (tax * (MilesK8 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK8 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");
					*/
				}
				//==============================================================LUCKNOW ECO============================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
					
				{
					
					totalCost = (tax * (MilesK12 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK12 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
					
				{
					
					totalCost = ( tax * (MilesK12 + eco)) / 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK12 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				{
					
					totalCost = (tax * (MilesK12 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK12 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				
				{
					
					totalCost = (tax * (MilesK12 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK12 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//============================================================DELHI ECO=================================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
					
				{
					
					totalCost = (tax * (MilesK20 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK20 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");
					*/
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
					
				{
					
					totalCost = ( tax * (MilesK20 + eco))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK20 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					//txtPrice.setText(Total);
					/*
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				{
					
					totalCost = (tax * (MilesK20 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK20 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				
				{
					
					totalCost = (tax * (MilesK20 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK20 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//====================================================================MUMBAI ECO========================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
					
				{
					
					totalCost = (tax * (MilesK30 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK30 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");
					*/
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
					
				{
					
					totalCost = ( tax * (MilesK30 + eco))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK30 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");
					*/
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				{
					
					totalCost = (tax * (MilesK30 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK30 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				
				{
					
					totalCost = (tax * (MilesK30 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK30 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//=============================================================CHANDIGARH ECO============================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
					
				{
					
					totalCost = (tax * (MilesK1 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK1 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");
					*/
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
					
				{
					
					totalCost = ( tax * (MilesK1 + eco))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK1 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				{
					
					totalCost = (tax * (MilesK1 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK1 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				
				{
					
					totalCost = (tax * (MilesK1 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK1 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//==============================================================GANDINAGAR ECO============================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("GANDHINAGAR"))
					
				{
					
					totalCost = (tax * (MilesK2 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK2 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("GANDINAGAR"))
					
				{
					
					totalCost = ( tax * (MilesK2 + eco)) / 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK2 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("GANDINAGAR"))
				{
					
					totalCost = (tax * (MilesK2 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK2 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("GANDINAGAR"))
				
				{
					
					totalCost = (tax * (MilesK2 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK2 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//============================================================LADAKH ECO=================================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
					
				{
					
					totalCost = (tax * (MilesK3 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK3 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
					
				{
					
					totalCost = ( tax * (MilesK3 + eco))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK3 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				{
					
					totalCost = (tax * (MilesK3 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK3 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				
				{
					
					totalCost = (tax * (MilesK3 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK3 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//================================================SHIMLA ECO===========================================================================================
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
					
				{
					
					totalCost = (tax * (MilesK4 + eco))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 + eco);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK4 + eco + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
					
				{
					
					totalCost = ( tax * (MilesK4 + eco))	/ 100;
					String sTax = String.format("$%.2f", (totalCost + eco) - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 + eco);//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK4 + eco + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				{
					
					totalCost = (tax * (MilesK4 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK4 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");
					*/
				}
				
				else if ((rdbtneco.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				
				{
					
					totalCost = (tax * (MilesK4 + eco * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK4 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("ECO");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				
				//========================================================================================================================================================
				//===================================================DDN STD========================================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				{
					
					totalCost = (tax * MilesK8)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK8 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				{
					
					totalCost = (tax * (MilesK8 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK8 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				
				{
					
					totalCost = ( tax * MilesK8 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 18);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 );//
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK8 + totalCost) - 18);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DEHRADUN"))
				
				{
					
					totalCost = (tax * (MilesK8 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 18);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK8 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK8 + totalCost) * 2) - 18);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//============================DELHI STD================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				
				{
					
					totalCost = (tax * MilesK20)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK20 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				{
					
					totalCost = (tax * (MilesK20 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK20 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				
				{
					
					totalCost = ( tax * MilesK20 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK20 );
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK20 + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("DELHI"))
				
				{
					
					totalCost = (tax * (MilesK20 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK20 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK20 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//======================================LKO STD==============================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
			
				{
					
					totalCost = (tax * MilesK12)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK12 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");
					*/
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				{
					
					totalCost = (tax * (MilesK12 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK12 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");
					*/
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				
				{
					
					totalCost = ( tax * MilesK12 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 16);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK12);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK12 + totalCost) - 16);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");
					*/
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LUCKNOW"))
				
				{
					
					totalCost = (tax * (MilesK12 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 16);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK12 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK12 + totalCost) * 2) - 16);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//=======================================MUMBAI STD=======================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				
				{
					
					totalCost = (tax * MilesK30)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK30 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				{
					
					totalCost = (tax * (MilesK30 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK30 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				
				{
					
					totalCost = ( tax * MilesK30 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 24);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK30 );
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK30 + totalCost) - 24);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("MUMBAI"))
				
				{
					
					totalCost = (tax * (MilesK30 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 24);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK30 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK30 + totalCost) * 2) - 24);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//=============================================CHNADIGARH STD========================================
				if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				{
					
					totalCost = (tax * MilesK1)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK1 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				{
					
					totalCost = (tax * (MilesK1 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK1 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				
				{
					
					totalCost = ( tax * MilesK1 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 19);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK1 );
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK1 + totalCost) - 19);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("CHANDIGARH"))
				
				{
					
					totalCost = (tax * (MilesK1 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 19);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK1 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK1 + totalCost) * 2) - 19);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//========================================GANDHINAGAR STD===============================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("GANDHINAGAR"))
				
				{
					
					totalCost = (tax * MilesK2)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK2 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("GANDHINAGAR"))
				{
					
					totalCost = (tax * (MilesK2 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK2 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("GANDHINAGAR"))
				
				{
					
					totalCost = ( tax * MilesK2 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 17);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK2 );
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK2 + totalCost) - 17);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("GANDHINAGAR"))
				
				{
					
					totalCost = (tax * (MilesK2 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 17);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK2 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK2 + totalCost) * 2) - 17);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				//=======================LADAKH STD===========================================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
			
				{
					
					totalCost = (tax * MilesK3)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK3 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				{
					
					totalCost = (tax * (MilesK3 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK3 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				
				{
					
					totalCost = ( tax * MilesK3 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 11);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK3 );
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK3 + totalCost) - 11);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("LADAKH"))
				
				{
					
					totalCost = (tax * (MilesK3 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 11);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK3 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK3 + totalCost) * 2) - 11);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				//=====================================SHIMLA STD==================================================
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				
				{
					
					totalCost = (tax * MilesK4)	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", MilesK4 + totalCost);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnAdult.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				{
					
					totalCost = (tax * (MilesK4 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 * 2);
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK4 + totalCost) * 2);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("ONE");
					txtChild.setText("NIL");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnSingleTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				
				{
					
					totalCost = ( tax * MilesK4 )	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", MilesK4 );
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", (MilesK4 + totalCost) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("ONE WAY");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");*/
					
				}
				else if ((cmbClass.isSelected()) && (rdbtnReturnTicket.isSelected()) && (rdbtnChild.isSelected()) && cmbDestination.getSelectedItem().equals("SHIMLA"))
				
				{
					
					totalCost = (tax * (MilesK4 * 2))	/ 100;
					String sTax = String.format("$%.2f", totalCost - 20);
					txtTax.setText(sTax);
					String subTotal = String.format("$%.2f", (MilesK4 * 2));
					txtSubTotal.setText(subTotal);
					String Total = String.format("$%.2f", ((MilesK4 + totalCost) * 2) - 20);
					txtTotal.setText(Total);
					/*txtPrice.setText(Total);
					txtClass.setText("STD");
					txtTicket.setText("RETURN");
					txtAdult.setText("NIL");
					txtChild.setText("ONE");
					*/
				}
//========================================================STD OVER==========================================================
				
			}
		});
		btnTotal.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
//=========================================================Time=====================================================================
				
				Calendar timer = Calendar.getInstance();
				timer.getTime();
				SimpleDateFormat tTime = new SimpleDateFormat("HH:mm:ss");
				txtTime.setText(tTime.format(timer.getTime()));
				
//=====================================================Ticket No.=======================================================================	
				int num1 ;
				String q1 =" ";
				num1 = 1325 + (int) (Math.random()*4328);
				q1 += num1 + 1325;
				txtTicketNo.setText(q1);
				
//=====================================================To From==============================================================
				txtFrom.setText("KANPUR");
				txtTo.setText((String) cmbDestination.getSelectedItem()+" *");
				
//====================================================Date=====================================================================
				SimpleDateFormat tdate = new SimpleDateFormat("dd:MM:yyyy");
				txtDate.setText(tdate.format(timer.getTime()));
				
//=================================================================================================================================
				txtRoute.setText("ANY");
				
			}
		});
		btnTotal.setBounds(10, 162, 89, 23);
		frame.getContentPane().add(btnTotal);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtTax.setText(null);
				txtSubTotal.setText(null);
				txtTotal.setText(null);
				rdbtnAdult.setSelected(false);
				rdbtnChild.setSelected(false);
				cmbClass.setSelected(false);
				rdbtneco.setSelected(false);
				rdbtnfclass.setSelected(false);
				cmbDestination.setSelectedItem("Destination");
				rdbtnSingleTicket.setSelected(false);
				rdbtnReturnTicket.setSelected(false);
				txtTo.setText(null);
				txtFrom.setText(null);
				txtPrice.setText(null);
				txtRoute.setText(null);
				txtDate.setText(null);
				txtTime.setText(null);
			//	txtClass.setText(null);
				//txtAdult.setText(null);
				txtTicketNo.setText(null);
			//	txtTicket.setText(null);
			//	txtChild.setText(null);
			}
		});
		btnReset.setBounds(125, 162, 89, 23);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","Are you sure?", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION)
				{
					System.exit(0);
				}
			}
		});
		btnExit.setBounds(241, 162, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setOrientation(SwingConstants.VERTICAL);
		separator_3.setBounds(336, 17, 13, 289);
		frame.getContentPane().add(separator_3);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setForeground(new Color(255, 255, 255));
		lblDate.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblDate.setBounds(360, 26, 57, 23);
		frame.getContentPane().add(lblDate);
		
		JSeparator separator_11 = new JSeparator();
		separator_11.setBounds(10, 15, 662, 0);
		frame.getContentPane().add(separator_11);
		
		JLabel label = new JLabel("");
		label.setBackground(Color.WHITE);
		label.setForeground(Color.WHITE);
		Image img = new ImageIcon(this.getClass().getResource("/download.jpg")).getImage();
		label.setIcon(new ImageIcon(img));
		label.setBounds(0, 0, 635, 488);
		frame.getContentPane().add(label);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBounds(10, 688, 1151, 2);
		frame.getContentPane().add(separator_5);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setOrientation(SwingConstants.VERTICAL);
		separator_4.setBounds(835, 228, 13, 342);
		frame.getContentPane().add(separator_4);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setBounds(10, 577, 825, 2);
		frame.getContentPane().add(separator_6);
		
		
		
		
		
		
		
						
		
}
}