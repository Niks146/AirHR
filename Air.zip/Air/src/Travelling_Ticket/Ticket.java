package Travelling_Ticket;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JSeparator;

import java.awt.Color;

import javax.swing.JTextPane;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import User_type.Sign;
import User_type.Login;
import User_type.User;




import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Ticket {

	private JFrame frame;
	private JTextField txtTo;
	private JTextField txtTno;
	private JTextField txtName;
	private JTextField txtCont;
	private JTextField txtDate;
	private JTextField txtTime;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ticket window = new Ticket();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ticket() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 360);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblFlightDetails = new JLabel("Flight Details");
		lblFlightDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblFlightDetails.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblFlightDetails.setBounds(10, 11, 136, 35);
		frame.getContentPane().add(lblFlightDetails);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(Color.BLACK);
		separator.setForeground(Color.BLACK);
		separator.setBounds(10, 11, 560, 10);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBackground(Color.BLACK);
		separator_1.setBounds(10, 43, 560, 10);
		frame.getContentPane().add(separator_1);
		
		JLabel lblFrom = new JLabel("From");
		lblFrom.setForeground(new Color(0, 0, 205));
		lblFrom.setHorizontalAlignment(SwingConstants.CENTER);
		lblFrom.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblFrom.setBounds(10, 57, 115, 35);
		frame.getContentPane().add(lblFrom);
		
		JLabel lblAirline = new JLabel("Airline");
		lblAirline.setHorizontalAlignment(SwingConstants.CENTER);
		lblAirline.setForeground(new Color(0, 0, 205));
		lblAirline.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAirline.setBounds(300, 57, 115, 35);
		frame.getContentPane().add(lblAirline);
		
		JLabel lblDepartureDate = new JLabel("Contact No.");
		lblDepartureDate.setHorizontalAlignment(SwingConstants.LEFT);
		lblDepartureDate.setForeground(new Color(0, 0, 205));
		lblDepartureDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblDepartureDate.setBounds(10, 215, 136, 35);
		frame.getContentPane().add(lblDepartureDate);
		
		JLabel lblTicketNo = new JLabel("Ticket No.");
		lblTicketNo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTicketNo.setForeground(new Color(0, 0, 205));
		lblTicketNo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblTicketNo.setBounds(445, 57, 115, 35);
		frame.getContentPane().add(lblTicketNo);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setForeground(Color.BLACK);
		separator_2.setBackground(Color.BLACK);
		separator_2.setBounds(10, 131, 560, 10);
		frame.getContentPane().add(separator_2);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo.setForeground(new Color(0, 0, 205));
		lblTo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblTo.setBounds(145, 57, 115, 35);
		frame.getContentPane().add(lblTo);
		
		JLabel lblName = new JLabel("Name");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setForeground(new Color(0, 0, 205));
		lblName.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblName.setBounds(10, 155, 136, 35);
		frame.getContentPane().add(lblName);
		
		JTextPane txtpnKanpur = new JTextPane();
		txtpnKanpur.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnKanpur.setText("Kanpur");
		txtpnKanpur.setBounds(35, 100, 96, 20);
		frame.getContentPane().add(txtpnKanpur);
		
		txtTo = new JTextField();
		txtTo.setBounds(175, 100, 96, 20);
		frame.getContentPane().add(txtTo);
		txtTo.setColumns(10);
		
		txtTno = new JTextField();
		txtTno.setColumns(10);
		txtTno.setBounds(455, 100, 96, 20);
		frame.getContentPane().add(txtTno);
		
		JTextPane txtpnAvianc = new JTextPane();
		txtpnAvianc.setText("Avianc");
		txtpnAvianc.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtpnAvianc.setBounds(315, 100, 96, 20);
		frame.getContentPane().add(txtpnAvianc);
		
		txtName = new JTextField();
		txtName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				try {
					Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ardb","root","Niksum150888");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		});
		txtName.setBounds(175, 152, 220, 35);
		frame.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		txtCont = new JTextField();
		txtCont.setColumns(10);
		txtCont.setBounds(175, 213, 220, 35);
		frame.getContentPane().add(txtCont);
		
		txtDate = new JTextField();
		txtDate.setColumns(10);
		txtDate.setBounds(175, 274, 115, 35);
		frame.getContentPane().add(txtDate);
		
		txtTime = new JTextField();
		txtTime.setColumns(10);
		txtTime.setBounds(445, 274, 115, 35);
		frame.getContentPane().add(txtTime);
		
		JLabel lblDate = new JLabel("Date");
		lblDate.setHorizontalAlignment(SwingConstants.LEFT);
		lblDate.setForeground(new Color(0, 0, 205));
		lblDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblDate.setBounds(10, 275, 136, 35);
		frame.getContentPane().add(lblDate);
		
		JLabel lblTime = new JLabel("Time");
		lblTime.setHorizontalAlignment(SwingConstants.LEFT);
		lblTime.setForeground(new Color(0, 0, 205));
		lblTime.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblTime.setBounds(328, 275, 96, 35);
		frame.getContentPane().add(lblTime);
	}
}
