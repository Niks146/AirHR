package User_type;
import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;


//import Travelling_Ticket.Travelling;
import java.awt.Color;

import javax.swing.JSeparator;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class Sign {

	//protected static String  = null;
	private JFrame frame;
	private JTextField txtFname;
	private JTextField txtLname;
	private JTextField txtEmail;
	private JTextField txtCont;
	private JTextField txtUser;
	private JTextField txtPas;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sign window = new Sign();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Sign() {
		initialize();
	}

	
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(230, 230, 250));
		frame.setBounds(100, 100, 388, 397);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblSignUpHere = new JLabel("Sign Up here...");
		lblSignUpHere.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblSignUpHere.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignUpHere.setBounds(99, 11, 160, 28);
		frame.getContentPane().add(lblSignUpHere);
		
		JLabel lblNewLabel = new JLabel("First Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(10, 65, 78, 28);
		frame.getContentPane().add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 50, 352, 8);
		frame.getContentPane().add(separator);
		
		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLastName.setBounds(10, 105, 78, 28);
		frame.getContentPane().add(lblLastName);
		
		JLabel lblContactNo = new JLabel("Email");
		lblContactNo.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblContactNo.setBounds(10, 145, 78, 28);
		frame.getContentPane().add(lblContactNo);
		
		JLabel label = new JLabel("Contact no.");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(10, 185, 78, 28);
		frame.getContentPane().add(label);
		
		JLabel lblCreateUsername = new JLabel("Create Username");
		lblCreateUsername.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCreateUsername.setBounds(10, 225, 122, 28);
		frame.getContentPane().add(lblCreateUsername);
		
		JLabel lblCreatePassword = new JLabel("Create Password");
		lblCreatePassword.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCreatePassword.setBounds(10, 265, 122, 28);
		frame.getContentPane().add(lblCreatePassword);
		
		txtFname = new JTextField();
		txtFname.setBounds(156, 62, 200, 28);
		frame.getContentPane().add(txtFname);
		txtFname.setColumns(10);
		
		txtLname = new JTextField();
		txtLname.setColumns(10);
		txtLname.setBounds(156, 102, 200, 28);
		frame.getContentPane().add(txtLname);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(156, 142, 200, 28);
		frame.getContentPane().add(txtEmail);
		
		txtCont = new JTextField();
		txtCont.setColumns(10);
		txtCont.setBounds(156, 182, 200, 28);
		frame.getContentPane().add(txtCont);
		
		txtUser = new JTextField();
		txtUser.setColumns(10);
		txtUser.setBounds(156, 222, 200, 28);
		frame.getContentPane().add(txtUser);
		
		txtPas = new JTextField();
		txtPas.setColumns(10);
		txtPas.setBounds(156, 262, 200, 28);
		frame.getContentPane().add(txtPas);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 304, 352, 8);
		frame.getContentPane().add(separator_1);
		
		final JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				    		
						String First_Name  = txtFname.getText();
						String Last_Name  = txtLname.getText();
						String Cont  = txtCont.getText();
						String Email  = txtEmail.getText();
						String username  = txtUser.getText();
						String Pas   = txtPas.getText();
						int len = Cont.length();
						
						
						//int Id = mobileNumber();
				        String msg = "" + First_Name;
		                msg += " \n";
		                if (len != 10) {
		                    JOptionPane.showMessageDialog(btnSignUp, "Enter a valid mobile number");
		                }

		                try {
		                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ardb", "root", "Niksum150888");

		                    String query = "INSERT INTO account (First_Name, Last_Name, Email, Mobile_Number,Username,Password)"+
		                    "values('" + First_Name + "','" + Last_Name + "','" + Email+ "','" +
		                       Cont.getBytes() + "','" + username + "','"+ Pas + "')";
		                    
		                    Statement sta = connection.createStatement();
		                    int x = sta.executeUpdate(query);
		                    if (x == 0) {
		                        JOptionPane.showMessageDialog(btnSignUp, "This is alraedy exist");
		                    } else {
		                        JOptionPane.showMessageDialog(btnSignUp,
		                            "Welcome, " + msg + "Your account is successfully created");
		                    }
		                    connection.close();
		                } catch (Exception exception) {
		                    exception.printStackTrace();
		                }
		            }
		        });
		        

		        btnSignUp.setFont(new Font("Tahoma", Font.PLAIN, 11));
		        btnSignUp.setBounds(71, 467, 150, 36);
//		        contentPane.add(btnSignUp);
		        btnSignUp.setBounds(20, 323, 89, 23);
		        frame.getContentPane().add(btnSignUp);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				JFrame frmLoginSystem = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmLoginSystem, "Confirm if you want to exit","Sign Up System", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
					System.exit(0);
				}
			}
		});
		btnExit.setBounds(267, 323, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtFname.setText(null);
				txtLname.setText(null);
				txtEmail.setText(null);
				txtCont.setText(null);
				txtUser.setText(null);
				txtPas.setText(null);
				
			}
		});
		btnReset.setBounds(143, 323, 89, 23);
		frame.getContentPane().add(btnReset);
	}
}
