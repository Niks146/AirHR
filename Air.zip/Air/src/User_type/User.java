package User_type;
//package Login_Sys;


import java.awt.Image;
import java.awt.EventQueue;

import javax.swing.ImageIcon;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

//import Travelling_Ticket.Travelling;

import User_type.Login;
import User_type.Sign;

import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JPanel;

public class User {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User window = new User();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public User() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(70, 130, 180));
		frame.setBounds(200, 200, 368, 290);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		Image img1 = new ImageIcon(this.getClass().getResource("/log.jpg")).getImage();
		
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				Login info =  new Login();
				Login.main(null);
				
				
				/*String password  = txtPassword.getText();
				String username  = txtUsername.getText();
				
				if (password.contains("nikki") && username.contains("niks")) {
					txtPassword.setText(null);
					txtUsername.setText(null);
					
					Travelling info  = new Travelling();
					Travelling.main(null);	
					
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Invalid Login Details","Login Error", JOptionPane.ERROR_MESSAGE);
					txtPassword.setText(null);
					txtUsername.setText(null);
					
				}*/
			}
		});
		
		
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnLogin.setBounds(238, 56, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		JButton btnReset = new JButton("Sign Up");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Sign info = new Sign();
				Sign.main(null);
				
				
				
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnReset.setBounds(238, 90, 89, 23);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame frmLoginSystem = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frmLoginSystem, "Confirm if you want to exit","Login System", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
					System.exit(0);
				}
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnExit.setBounds(238, 124, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 43, 330, 2);
		frame.getContentPane().add(separator);
		
		JLabel lblWel = new JLabel("Welcome to Airline Reservation System");
		lblWel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblWel.setHorizontalAlignment(SwingConstants.CENTER);
		lblWel.setBounds(10, 11, 330, 28);
		frame.getContentPane().add(lblWel);
		
		JLabel label = new JLabel("");	
		label.setLabelFor(label);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(10, 56, 218, 186);
		frame.getContentPane().add(label);
		Image img = new ImageIcon(this.getClass().getResource("/log.jpg")).getImage();
		label.setIcon(new ImageIcon(img));	
		
		
		
	}
}
